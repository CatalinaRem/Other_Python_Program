''' --------------------------
Do not change anything here 
------------------------------'''
import P12f

''' --------------------------
Put your code for the main part here 
------------------------------'''
number=[]
if __name__ == "__main__":
    n1,n2,n3=P12f.readInput()
    P12f.sort(n1,n2,n3)
