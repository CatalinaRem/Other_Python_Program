''' --------------------------
Do not change anything here 
------------------------------'''
from math import sqrt

from P10f import read, findPower

''' --------------------------
Put your code for the main part here 
------------------------------'''
if __name__ == "__main__":
    number=read()
    findPower(number)
    