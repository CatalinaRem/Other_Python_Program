n=int(input("Enter n: "))
for r in range(1,n+1):
    for c in range(1,r+1):
        print(r,end=" ")
    print()