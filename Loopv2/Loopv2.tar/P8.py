for r in range(1,13):
    for c in range(1,13):
        print(r*c, end="\t")
    print()